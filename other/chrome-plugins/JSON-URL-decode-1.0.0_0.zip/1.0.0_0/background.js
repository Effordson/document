chrome.runtime.onInstalled.addListener(function (details) {
    if (details.reason == "install") {
        chrome.tabs.create({ url: ("https://bit.ly/urlennde") })
    }
});

chrome.runtime.setUninstallURL("https://bit.ly/urlendeu")
