let obj = {}
let dat
let prettifyBtnClcked = false
let minifyBtnClcked = false
let prettifiedData

function onChangeHandler(e) {
    console.log("inside the function")

    if (e.target.files[0]) {
        document.getElementById('inputTextBox').value = "";
        const file = e.target.files[0];
        const fileReader = new FileReader();
        fileReader.readAsText(file, "UTF-8");
        fileReader.onload = (e) => {
            try {
                dat = JSON.parse(e.target.result)
                obj = JSON.stringify(dat)
                document.getElementById('inputTextBox').value = obj;
            }
            catch (event) {
                console.log(event)
                console.log(fileReader.result)
                document.getElementById('inputTextBox').value = fileReader.result;
                document.getElementById("outputTextBox").style.color = "red";
                document.getElementById('outputTextBox').innerHTML = event;
                obj = ""

            }
        }

    }
}

function prettifyData() {
    try {
        prettifyBtnClcked = true
        minifyBtnClcked = false
        var prettifyStr1 = JSON.parse(obj)
        var prettifyStr2 = JSON.stringify(prettifyStr1, null, 2)
        document.getElementById('outputTextBox').innerHTML = "<pre>" + prettifyStr2 + "</pre>"
        prettifiedData = prettifyStr2
        //prettifiedData = "<pre>" + prettifyStr2 + "</pre>"
        console.log(prettifiedData)

        document.querySelectorAll('#outputTextBox').forEach(el => {
            console.log("inside highlight function")
            console.log(el)

            document.getElementById("outputTextBox").style.whiteSpace = "pre";
            console.log("highlighter triggered")
            hljs.highlightElement(el);
            var objValLen = document.querySelectorAll(".hljs-string").length


            for (var i = 0; i < objValLen; i++) {
                var obj1 = document.querySelectorAll(".hljs-string")[i].innerText
                if (obj1.includes("https://")) {
                    document.getElementById("outputTextBox").style.color = "green";
                    document.querySelectorAll(".hljs-string")[i].innerHTML = "<a target='_blank' href=" + obj1 + ">" + obj1 + "</a>"


                }
            }
        });
    }
    catch (e) {
        console.log(e)
        document.getElementById('outputTextBox').innerHTML = "INVALID JSON CONTENT"
        console.log("Invalid json content")
    }
}

function minifyData() {
    try {
        minifyBtnClcked = true
        prettifyBtnClcked = false
        var minifyStr1 = JSON.parse(obj)
        var minifyStr2 = JSON.stringify(minifyStr1, null, 2)
        document.getElementById('outputTextBox').textContent = minifyStr2;
        prettifiedData = minifyStr2
        document.querySelectorAll('#outputTextBox').forEach(el => {
            document.getElementById("outputTextBox").style.whiteSpace = "normal";
            console.log("highlighter triggered")
            hljs.highlightElement(el);
        });
    }
    catch (e) {
        console.log(e)
        document.getElementById('outputTextBox').innerHTML = "INVALID JSON CONTENT"
        console.log("Invalid json content")
    }
}

function clearData() {
    document.getElementById('inputTextBox').value = "";
    document.getElementById('outputTextBox').innerHTML = "";
    obj = ""
}


function handleClick() {
    if (prettifyBtnClcked === true) {
        const elem = document.createElement('textarea');
        elem.value = prettifiedData;
        document.body.appendChild(elem);
        elem.select();
        document.execCommand('copy');
        swal("Text copied!");
        document.body.removeChild(elem);
    } else if (minifyBtnClcked === true) {
        const elem = document.createElement('textarea');
        elem.value = JSON.stringify(JSON.parse(prettifiedData));
        document.body.appendChild(elem);
        elem.select();
        document.execCommand('copy');
        swal("Text copied!");
        document.body.removeChild(elem);
    }
    document.body.removeChild(dummy);
}

document.addEventListener('DOMContentLoaded', function () {
    document.getElementById('uploadFleBtn')
        .addEventListener('change', onChangeHandler);
});

document.addEventListener('DOMContentLoaded', function () {
    document.getElementById('prettifyBtn')
        .addEventListener('click', prettifyData);
});

document.addEventListener('DOMContentLoaded', function () {
    document.getElementById('minifyBtn')
        .addEventListener('click', minifyData);
});

document.getElementById("inputTextBox").onchange = function () {
    obj = document.getElementById("inputTextBox").value;

};

document.addEventListener('DOMContentLoaded', function () {
    document.getElementById('clearBtn')
        .addEventListener('click', clearData);
});

document.addEventListener('DOMContentLoaded', function () {
    document.getElementById('copyBtn')
        .addEventListener('click', handleClick);
    console.log("copy func triggered")
});

function download(filename, text) {
    console.log("download function triggered")
    var element = document.createElement('a');
    if (prettifyBtnClcked === true) {
        element.setAttribute('href', 'data:text/plain;charset=utf-8,' + text);
        element.setAttribute('download', filename);

        element.style.display = 'none';
        document.body.appendChild(element);

        element.click();

        document.body.removeChild(element);
    }
    else if (minifyBtnClcked === true) {
        element.setAttribute('href', 'data:text/plain;charset=utf-8,' + JSON.stringify(JSON.parse(text)));
        element.setAttribute('download', filename);

        element.style.display = 'none';
        document.body.appendChild(element);

        element.click();

        document.body.removeChild(element);
    }
}

document.getElementById("downloadFile").addEventListener("click", function () {
    var text = prettifiedData
    var filename = "file.json";

    download(filename, text);
}, false);